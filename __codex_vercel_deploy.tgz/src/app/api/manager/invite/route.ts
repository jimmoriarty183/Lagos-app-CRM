import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";

function json(status: number, payload: any) {
  return NextResponse.json(payload, { status });
}

function getBaseUrl(req: Request) {
  const site = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (site) return site.replace(/\/$/, "");

  const origin = req.headers.get("origin")?.trim();
  if (origin) return origin.replace(/\/$/, "");

  const app = process.env.NEXT_PUBLIC_APP_URL?.trim();
  if (app) return app.replace(/\/$/, "");

  return "http://localhost:3000";
}

function isAlreadyRegisteredError(message: string) {
  const m = message.toLowerCase();
  return m.includes("already been registered") || m.includes("already registered");
}

async function sendExistingUserAccessEmail(input: {
  to: string;
  actionLink: string;
  businessSlug: string;
}) {
  const resendKey = process.env.RESEND_API_KEY;
  const fromEmail = process.env.INVITE_FROM_EMAIL || process.env.RESEND_FROM_EMAIL;
  if (!resendKey || !fromEmail) return false;

  const { Resend } = await import("resend");
  const resend = new Resend(resendKey);

  await resend.emails.send({
    from: fromEmail,
    to: input.to,
    subject: `You've been granted manager access to ${input.businessSlug}`,
    html: `<p>You already have an account.</p><p>Click to confirm access to <strong>${input.businessSlug}</strong>:</p><p><a href="${input.actionLink}">Open business access</a></p>`,
  });

  return true;
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({} as any));
    const business_id = String(body?.business_id || body?.businessId || "").trim();
    const email = String(body?.email || "").trim().toLowerCase();

    if (!business_id) return json(400, { error: "business_id required" });
    if (!email) return json(400, { error: "email required" });

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.SUPABASE_URL;
    const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_KEY;

    if (!supabaseUrl) return json(500, { error: "Missing SUPABASE_URL" });
    if (!serviceKey) return json(500, { error: "Missing SUPABASE_SERVICE_ROLE_KEY" });

    const supabase = createClient(supabaseUrl, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: existing, error: selErr } = await supabase
      .from("business_invites")
      .select("id,status")
      .eq("business_id", business_id)
      .eq("email", email)
      .maybeSingle();

    if (selErr) return json(500, { error: selErr.message });

    let invite_id: string;

    if (existing?.id) {
      if (existing.status === "PENDING") {
        invite_id = existing.id;
      } else {
        const { error: updErr } = await supabase
          .from("business_invites")
          .update({
            status: "PENDING",
            accepted_at: null,
            accepted_by: null,
            revoked_at: null,
            revoked_by: null,
          })
          .eq("id", existing.id);

        if (updErr) return json(500, { error: updErr.message });
        invite_id = existing.id;
      }
    } else {
      const { data: created, error: createErr } = await supabase
        .from("business_invites")
        .insert({
          business_id,
          email,
          role: "MANAGER",
          status: "PENDING",
        })
        .select("id")
        .limit(1)
        .maybeSingle();

      if (createErr || !created?.id) {
        return json(500, { error: createErr?.message || "Insert failed" });
      }
      invite_id = created.id;
    }

    const { data: business } = await supabase
      .from("businesses")
      .select("slug")
      .eq("id", business_id)
      .maybeSingle();

    const businessSlug = String(business?.slug || "business");

    const baseUrl = getBaseUrl(req);
    const redirectTo = `${baseUrl}/invite?invite_id=${encodeURIComponent(invite_id)}`;

    const { error: authErr } = await supabase.auth.admin.inviteUserByEmail(email, { redirectTo });

    if (authErr && isAlreadyRegisteredError(authErr.message)) {
      const { data: linkData, error: linkErr } = await supabase.auth.admin.generateLink({
        type: "magiclink",
        email,
        options: { redirectTo },
      });

      if (linkErr || !linkData?.properties?.action_link) {
        return json(400, {
          error: `Supabase existing-user link failed: ${linkErr?.message || "No action link"}`,
          invite_id,
          redirectTo,
        });
      }

      const sent = await sendExistingUserAccessEmail({
        to: email,
        actionLink: linkData.properties.action_link,
        businessSlug,
      });

      return json(200, {
        ok: true,
        invite_id,
        email,
        status: "PENDING",
        email_sent: sent,
        redirectTo,
        existing_user: true,
      });
    }

    if (authErr) {
      return json(400, {
        error: `Supabase invite email failed: ${authErr.message}`,
        invite_id,
        redirectTo,
      });
    }

    return json(200, {
      ok: true,
      invite_id,
      email,
      status: "PENDING",
      email_sent: true,
      redirectTo,
      existing_user: false,
    });
  } catch (e: any) {
    return json(500, { error: e?.message || "Unexpected error" });
  }
}
